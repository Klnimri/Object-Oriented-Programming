package mainclass;              //Student names: Khalid Nimri(2140145) - Mohammed Allagany(2142374)
    
import java.util.*;

public
        class MainClass {

    public static
            void main(String[] args) throws Exception {

            DoubleLinkedList EmployeesRecords = new DoubleLinkedList();
            Employee Emp = new Employee();
            EmployeesRecords.InsertLast(Emp);
            showMenu(Emp);
            
            }
            public static void showMenu(Employee a) throws Exception{
                System.out.println("Please pick what operation you want to perform:\n"
                        + "1.Insert Employee\n"
                        + "2.Delete Employee\n"
                        + "3.Update Employee\n"
                        + "4.Show Employee\n");
                Scanner Input = new Scanner(System.in);
                int CustomerPick = Input.nextInt();
                                   Input.nextLine();
                switch(CustomerPick){
                    case 1:
                        a.EmpName = a.newEmpName();
                        a.EmpID = a.newEmpID();
                        a.Fday = a.newEmpFday();
                        a.EmpPhoneNum = a.newEmpPhoneNum();
                        a.WorkHours = a.newEmpWorkHours();
                        a.Salary = a.newEmpSalary();
                        a.InsertLast(a.EmpName);
                        a.InsertLast(a.EmpID);
                        a.InsertLast(a.Fday);
                        a.InsertLast(a.EmpPhoneNum);
                        a.InsertLast(a.WorkHours);
                        a.InsertLast(a.Salary);
                        System.out.println("\ndo you want to get back to the menu?\n"
                                        + "1.Yes\n"
                                        + "2.No\n");
                           int CustomersReply = Input.nextInt();
                                                Input.nextLine();
                            if (CustomersReply == 1){
                                showMenu(a);
                               
                            }
                            else if(CustomersReply == 2){
                                break;
                            }
                            else {
                                throw new Exception("Wrong entry..");
                            }
                        break;
                    case 2: 
                            if(a.isEmpty()){
                                System.out.println("\nThe list is already empty\n");
                                showMenu(a);
                                
                            }
                            else
                            {
                            a.DeleteNode();
                            a.DeleteNode();
                            a.DeleteNode();
                            a.DeleteNode();
                            a.DeleteNode();
                            a.DeleteNode(); 
                            }
                            System.out.println("\ndo you want to get back to the menu?\n"
                                        + "1.Yes\n"
                                        + "2.No \n");
                            CustomersReply = Input.nextInt();
                                             Input.nextLine();
                            if (CustomersReply == 1){
                                showMenu(a);
                              
                            }
                            else if(CustomersReply == 2){
                                break;
                            }
                            else {
                                throw new Exception("Wrong entry..");
                            }
                            
                            break;
                    case 3: if(a.isEmpty()){
                                System.out.println("\nThe list is already empty\n");
                                showMenu(a);
                                
                            }
                    else {
                            System.out.println("Pick what you want to Update:\n"
                            + "1.Employee's name.\n"
                            + "2.Employee's ID.\n"
                            + "3.Employee's First day.\n"
                            + "4.Employee's Phone number.\n"
                            + "5.Employee's Work hours\n"
                            + "6.Employee's Salary.\n");
                           int CustomerUpdatePick = Input.nextInt();
                                                    Input.nextLine();
                           switch(CustomerUpdatePick){
                               case 1: 
                                     
                                    a.newEmpName();
                                    System.out.println("\ndo you want to get back to the menu?\n"
                                        + "1.Yes\n"
                                        + "2.No \n");
                             CustomersReply = Input.nextInt();
                                              Input.nextLine();
                            if (CustomersReply == 1){
                                showMenu(a);
                                
                            }
                            else if(CustomersReply == 2){
                                break;
                            }
                            else {
                                throw new Exception("Wrong entry..");
                            }
                                        break;
                               case 2: a.newEmpID();
                               System.out.println("\ndo you want to get back to the menu?\n"
                                        + "1.Yes\n"
                                        + "2.No \n");
                            CustomersReply = Input.nextInt();
                                             Input.nextLine();
                            if (CustomersReply == 1){
                                showMenu(a);
                                
                            }
                            else if(CustomersReply == 2){
                                break;
                            }
                            else {
                                throw new Exception("Wrong entry..");
                            }
                                        break;
                               case 3: a.newEmpFday();
                               System.out.println("\ndo you want to get back to the menu?\n"
                                        + "1.Yes\n"
                                        + "2.No \n");
                            CustomersReply = Input.nextInt();
                                             Input.nextLine();
                            if (CustomersReply == 1){
                                showMenu(a);
                               
                            }
                            else if(CustomersReply == 2){
                                break;
                            }
                            else {
                                throw new Exception("Wrong entry..");
                            }
                                        break;
                               case 4: a.newEmpPhoneNum();
                               System.out.println("\ndo you want to get back to the menu?\n"
                                        + "1.Yes\n"
                                        + "2.No \n");
                            CustomersReply = Input.nextInt();
                                             Input.nextLine();
                            if (CustomersReply == 1){
                                showMenu(a);
                                
                            }
                            else if(CustomersReply == 2){
                                break;
                            }
                            else {
                                throw new Exception("Wrong entry..");
                            }
                                        break;
                               case 5: a.newEmpWorkHours();
                               System.out.println("\ndo you want to get back to the menu?\n"
                                        + "1.Yes\n"
                                        + "2.No \n");
                            CustomersReply = Input.nextInt();
                                             Input.nextLine();
                            if (CustomersReply == 1){
                                showMenu(a);
                                
                            }
                            else if(CustomersReply == 2){
                                break;
                            }
                            else {
                                throw new Exception("Wrong entry..");
                            }
                                        break;
                               case 6: a.newEmpSalary();
                               System.out.println("\ndo you want to get back to the menu?\n"
                                        + "1.Yes\n"
                                        + "2.No \n");
                            CustomersReply = Input.nextInt();
                                             Input.nextLine();
                            if (CustomersReply == 1){
                                showMenu(a);
                            }
                            else if(CustomersReply == 2){
                                break;
                            }
                            else {
                                throw new Exception("Wrong entry..");
                            }
                                        break;
                               default: throw new Exception("Wrong");       
                    }}
                           break;
                    case 4: if(a.isEmpty()){
                                System.out.println("\nThe list is already empty\n");
                                showMenu(a);
                              
                            }
                    else { 
                            System.out.println("Name---ID---FirstDay---PhoneNumber---WorkHours---Salary");
                            a.DisplayForward(); }
                            System.out.println("\ndo you want to get back to the menu?\n"
                                        + "1.Yes\n"
                                        + "2.No \n");
                             CustomersReply = Input.nextInt();
                                              Input.nextLine();
                            if (CustomersReply == 1){
                                showMenu(a);
                                
                            }
                            else if(CustomersReply == 2){
                                break;
                            }
                            else {
                                throw new Exception("Wrong entry..");
                            }
                            break;
                    default:
                        throw new Exception("Wrong");
                }
                
            }
    
}
