package mainclass;          //Student names: Khalid Nimri(2140145) - Mohammed Allagany(2142374)

public
        class Node extends Employee {   
    
    Object data;
    Node next;
    Node previous;
    
    public Node(Object data){
        this.data = data;
}
}