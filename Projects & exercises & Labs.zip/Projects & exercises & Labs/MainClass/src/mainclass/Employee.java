package mainclass;          //Student names: Khalid Nimri(2140145) - Mohammed Allagany(2142374)

import java.util.*;


public
        class Employee extends DoubleLinkedList {
    String EmpName;
    int EmpID;
    String Fday;
    long EmpPhoneNum;
    int WorkHours;
    int Salary;
    int Counter = 0;
    Scanner Input = new Scanner(System.in);
    public DoubleLinkedList E1 = new DoubleLinkedList();
    
    public Employee() {
    
}
    public String newEmpName() {
    
    System.out.print("\nPlease the name of the employee: "); 
    EmpName = Input.nextLine();
    
    return EmpName;
    }
    public int newEmpID(){
        try {
            do
            {                
                 System.out.print("\nPlease enter the ID of the employee: ");
                 EmpID = Input.nextInt();
                 Input.nextLine();
            }
            while (EmpID <= 0 || EmpID > 1999999999);
    }
       
        catch(Exception e){
            System.out.print("\nPlease enter a valid ID number of the employee \"e.g >> 1423543258\" ");
            EmpID = Input.nextInt();
            Input.nextLine();
        }
    return EmpID; }
    
    public String newEmpFday(){
    System.out.print("\nPlease enter the date of the employee's first day: ");
    Fday = Input.nextLine();
    return Fday;
    }
    public long newEmpPhoneNum(){
        try
        {
            do
            {                
            System.out.print("\nPlease enter the phone number of the employee: ");
            EmpPhoneNum = Input.nextLong();
                          Input.nextLine();
            }
            while (EmpPhoneNum <= 0 || EmpPhoneNum > 1999999999);
            
        }
        catch(Exception e){
             System.out.print("\nWrong entry\n");
             
        }
    return EmpPhoneNum;
    }
    public int newEmpWorkHours(){
        try{
            do
            {                
                System.out.print("\nPlease enter the employee work hours per day: ");
    WorkHours = Input.nextInt();
                Input.nextLine();
            }
            while (WorkHours > 15 || WorkHours <= 0);
        }
        catch(Exception e){
            System.out.print("\nWrong entry\n");
        }
    return WorkHours;
    }
    public int newEmpSalary(){
        try{
            do
            {                
            System.out.print("\nPlease enter The empolyee's salary: ");
            Salary = Input.nextInt();
            Input.nextLine(); 
            }
            while (Salary <= 0);
         }
        catch(Exception e){
            System.out.print("\nWrong entry\n");
        }
    return Salary;
    }
    
}