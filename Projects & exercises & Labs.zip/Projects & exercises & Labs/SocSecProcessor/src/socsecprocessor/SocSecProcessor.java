package socsecprocessor;                    //7614

import javax.swing.*;
import java.io.*;
import java.util.*;

public class SocSecProcessor extends SocSecException {

    
    public static void main(String[] args) {
        String SocialNumberStr;
        String Name;
        boolean Status;
        
        Name = JOptionPane.showInputDialog("Please enter your name");
        SocialNumberStr = JOptionPane.showInputDialog("Please enter the social security number");
        
            try {
             isValid(SocialNumberStr);
             throw new SocSecException("Please enter again");
            }
            
        catch(SocSecException e){
            e.getMessage();
        }
            
            while(Status = isValid(SocialNumberStr) == true){
                      SocialNumberStr = JOptionPane.showInputDialog("Wrong please enter the social security number again");

                }
        
        if (Status == false){
            JOptionPane.showMessageDialog(null, "Thank you for using the app\nYour name is:"+Name+
                    "\nYour Social security number is: "+ SocialNumberStr);
        }
              System.exit(0);

    }
    
    public static boolean isValid(String ssn) {
        
        
        
        if (ssn.length() != 11)      // Checked           // True: there is an exception 
        {                                                 // False: There is not an exception 
            JOptionPane.showMessageDialog(null, "Wrong number of characters");
            return true;
        }
        ////////////////////////////////////////////////////
        else if (ssn.charAt(3) != '-' || ssn.charAt(6) != '-')   // Checked
        {
            JOptionPane.showMessageDialog(null, "dashes at wrong positions");

                    return true;
                
            }
            
        
        ////////////////////////////////////////////////////
       
        return false;
        
        
    }

    public SocSecProcessor(String error) {
        super(error);
    }

}
