

package socsecprocessor;

import javax.swing.*;
import java.io.*;
import java.util.*;

public class SocSecException extends Exception {
    
    public SocSecException(String error){
        
        super(error);
        
    }
    
    
}
