/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package printwritertest;

import java.io.FileNotFoundException;
import java.io.PrintWriter;


public class Printwritertest {

   
    public static void main(String[] args) throws FileNotFoundException {
             //////// PrintWriter object
            PrintWriter outputFile = new PrintWriter("Numbers.txt");
            outputFile.println("Hello");
            outputFile.close();
            ////////
                }
    
}

        