import javax.swing.*; 

public class KiloConverter extends JFrame {
private JPanel panel1; 
private JLabel msgLabel;
private JTextField KiloTextField; 
final int WINDOW_WIDTH = 310; 
final int WINDOW_HEIGHT = 100; 


public KiloConverter() {
setTitle("C to F Converter");
setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
buildPanel();
add(panel1);
setLocationRelativeTo(null);
setVisible(true);
}
private void buildPanel(){
panel1 = new JPanel();
 

msgLabel = new JLabel("Enter a tempreture " + "in Celsius");
KiloTextField = new JTextField(10);
JButton calculateButton = new JButton("Calculate");
panel1.add(msgLabel); 
panel1.add(KiloTextField); 
panel1.add(calculateButton);
} 

public static void main(String[] args) {
    
KiloConverter KiloConv1 = new KiloConverter(); 

    }
}
