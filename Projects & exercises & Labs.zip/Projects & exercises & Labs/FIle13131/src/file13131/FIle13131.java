

package file13131;

import java.util.*;
import javax.swing.*;
import java.io.*;

public class FIle13131 {

    
    
    public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter rhaejfuah");
        String FileName= input.nextLine();
        
        PrintWriter F1 = new PrintWriter(FileName);
        F1.println("My name is khalid");
        
        
                
    }
    
}
