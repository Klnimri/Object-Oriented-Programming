package windowshadedesignergui;         //Student name: Khalid Nimri
                                        //Student ID: 2140145
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class WindowShadeDesignerGUI extends JFrame implements ActionListener
{
	//set size of the window
	private static int WIDTH=350;
	private static int HEIGHT=150;	
	/*Set an array of shades*/
	private String shades[]=
		{
				"Regular shades",
				"Folding shades",
				"Roman shades"
		};
	/*Set an array of sizes*/
	private String sizes[]=
		{
				"25 inches",
				"27 inches",
				"32 inches"
		};
	
	private JButton calButton;
	private JButton exitButton;
	JComboBox< String>styleCmbBox;		
	JComboBox< String>sizeCmbBox;
	/*constructor to setup the window*/
	public WindowShadeDesignerGUI()
	{
		setLayout(new BorderLayout());
		add(new JLabel("Welcome to Window Shade Designer"),BorderLayout.NORTH);
		/*create a panel with shade style*/
		JPanel shadePanel =new JPanel();
		shadePanel.setBorder(BorderFactory.createTitledBorder("Shade Style"));
		styleCmbBox=new JComboBox<>(shades);
		shadePanel.add(styleCmbBox);
		add(shadePanel,BorderLayout.WEST);
		
		/*create a panel with size style*/
		JPanel shadeSize =new JPanel();
		shadeSize.setBorder(BorderFactory.createTitledBorder("Shade Size"));
		sizeCmbBox=new JComboBox<>(sizes);
		shadeSize.add(sizeCmbBox);
		add(shadeSize,BorderLayout.CENTER);
		
		/*objects of Jbutton for calculate and exit buttons*/
		calButton= new JButton("Calculate");
		calButton.addActionListener(this);
		
		exitButton= new JButton("Exit");
		exitButton.addActionListener(this);
		
		JPanel southPanel=new JPanel();
		southPanel.setLayout(new FlowLayout());
		southPanel.add(calButton);
		southPanel.add(exitButton);
		
		add(southPanel,BorderLayout.SOUTH);
		
	}
	/*main function */
	public static void main(String[] args) 
	{
		JFrame frame =new WindowShadeDesignerGUI();
		frame.setTitle("Window Shade Designer");
		frame.setSize(WIDTH, HEIGHT);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}
	/*Override actionPerformed method*/
	public void actionPerformed(ActionEvent e) 
	{
		/*checking if user press exit button*/
		if(e.getSource()==exitButton)
		{
			System.exit(0);
		}
		/*checking if user press calculate button*/
		if(e.getSource()==calButton)
		{
			final int BASE_FEE=50;
			int styleCost=0;
			int sizeCost=0;
			int totalCost=0;
			//Get the items from the combo box
			String style=styleCmbBox.getSelectedItem().toString();
			String size=sizeCmbBox.getSelectedItem().toString();
			
			if(style.equals("Regular shades"))
				styleCost=0;
			else if(style.equals("Folding shades"))
				styleCost=10;
			else if(style.equals("Roman shades"))
				styleCost=15;
			
			if(size.equals("25 inches"))
				sizeCost=0;
			else if(size.equals("27 inches"))
				sizeCost=2;
			else if(size.equals("32 inches"))
				sizeCost=4;
			//calculate total cost
			totalCost=BASE_FEE+styleCost+sizeCost;
			
			JOptionPane.showMessageDialog(null, "Total cost:$"+String.valueOf(totalCost));			
		}
	}
}