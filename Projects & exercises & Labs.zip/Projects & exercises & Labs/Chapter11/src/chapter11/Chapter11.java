
package chapter11;

    import java.io.*;
    import javax.swing.*;
    import java.util.*;

public class Chapter11 extends Exception {

    
    public static void main(String[] args) throws IOException,FileNotFoundException {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /*
       
        File name;
        Scanner inputFile;
        String FileName;
        
        FileName = JOptionPane.showInputDialog("Please enter the Name of the File.");
        
        try {
            name = new File(FileName);
            inputFile = new Scanner(name);
            JOptionPane.showMessageDialog(null, inputFile);
        }
        catch(FileNotFoundException e) {
            
            JOptionPane.showMessageDialog(null, "File not found");
        }
       
        
            JOptionPane.showMessageDialog(null,"Thank you for using the exception catcher app");
            System.exit(0);
    }
    */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
       /*
       String str = "abcde";
       int number;
       
       try{
           number = Integer.parseInt(str);
       }
       catch(NumberFormatException e){
           System.out.println("Conversion error: "+ e.getMessage());
       }
       */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      /*
        Exception e = new Exception();     //To catch all the expceptions from the exception class.
        e = new NumberFormatException();   // disclude the error and Runtime excpetions from this.
        e = new NumberFormatException();   // Now you can type e in the parameter in the catch brakets to catch all the exceptions
        */
       
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
     //Handling an exception using try and catch
        
try {
    File f = new File("MyFile.txt");
    Scanner InputFile = new Scanner(f);
    while (InputFile.hasNext()){
        System.out.println(InputFile.nextLine());
    }
}
    catch(FileNotFoundException e){
            System.out.println("The file is not found");
            }
}
       */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
   //Handling exception using Throws >>>>> the same but put (Throws FileNotFoundException) in the main method's header.
   
   /*
   
   
   try {
    File file = new File("MyFile.txt");
    Scanner InputFile = new Scanner(file);
    while (InputFile.hasNext()){
        System.out.println(InputFile.nextLine());
    }
}
    catch(FileNotFoundException e){
            System.out.println("The file is not found");
            }
}
    */
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    //Handling exceptions using throw >>> throw is used to handle a specific exception manually
    /*
        throw new FileNotFoundException("File not found");
    
    */
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    // To write data to a binary file you must create objects from the following classes
    
    /*
   
    int[] numbers = {2,5,3,2,7,4,2,3,8,6};
    
    FileOutputStream Fstream = new FileOutputStream("MyInfo.dat"); //Opening the file phase
    DataOutputStream outputFile = new DataOutputStream(Fstream);   //Allowing you to write in the file phase
    
    System.out.println("Writing the number into the file...");
    
   for (int i = 0 ; i<=numbers.length-1 ; i++){
       outputFile.writeInt(numbers[i]);
       
   }
   System.out.println("Done.");
   
   outputFile.close();
   
 */
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    // how to read from binary file.  >>>> to read string use writeUTF method.
    /*
   
    
   FileInputStream Fread = new FileInputStream("MyInfo.dat");
   DataInputStream inputFile = new DataInputStream(Fread);
   boolean endOfFile = false;
   
   while(!endOfFile){
       try{
          int number = inputFile.readInt();
           System.out.println(number);
       }
       catch (EOFException e){
           endOfFile = true;
       }
       
   }
    System.out.println("Done");
    inputFile.close();
    
    */
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
   
    /*

   //How to write a string into a binary file.
   
   String name = "Khalid";
   
   FileOutputStream ws1 = new FileOutputStream("MyInfo.dat" , true);  // >> to avoid deleting the current data in the file type true in the second arg
   DataOutputStream StringWriting = new DataOutputStream(ws1);        // >> and false means that the file will be erased if it already exists
                                                                      // >> Only exists and used in the FileOutputStream class!!
   StringWriting.writeUTF(name);
   StringWriting.close();

   */
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    //Sequential vs Random access Files >>> Binary files are sequential access. 
    
    
    
try {
    RandomAccessFile A1 = new RandomAccessFile("MyInfo.dat","rw"); // this is how you open the RandomAccess file
                                                                   // There're r and rw modes either read only or read and write mode.
                                                                   // r mode throws FileNotFoundException & rw throws IOException
    char[] letters= {'a','b','c','d','e','f','g'};
    System.out.println("Writing data to the file...");
    
    for(int counter = 0 ; counter < letters.length ; counter++){
            A1.writeChar(letters[counter]);
    }
    System.out.println("Done");
    A1.close();
 
   
}
catch(IOException o){
    System.out.println("File not found!");
}

     
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                   
                                                                   
                                                                   
                                                                   
    }   
}
