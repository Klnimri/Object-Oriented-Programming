
package milestokilometersconverter;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class MilesToKilometersConverter extends JFrame {
  // Declare GUI components
  private JLabel milesLabel;
  private JTextField milesTextField;
  private JLabel kilometersLabel;
  private JTextField kilometersTextField;
  private JButton convertButton;

  // Constructor
  public MilesToKilometersConverter() {
    // Set the frame's title
    setTitle("Miles to Kilometers Converter");

    // Set the layout to GridLayout
    setLayout(new GridLayout(3, 2));

    // Create the components
    milesLabel = new JLabel("Enter number of miles:");
    milesTextField = new JTextField(10);
    kilometersLabel = new JLabel("Kilometers:");
    kilometersTextField = new JTextField(10);
    kilometersTextField.setEditable(false);
    convertButton = new JButton("Convert");

    // Add the components to the frame
    add(milesLabel);
    add(milesTextField);
    add(kilometersLabel);
    add(kilometersTextField);
    add(convertButton);

    // Add an action listener to the convert button
    convertButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        // Convert the miles to kilometers and display the result
        double miles = Double.parseDouble(milesTextField.getText());
        double kilometers = miles * 1.60934;
        kilometersTextField.setText(String.format("%.2f", kilometers));
      }
    });

    // Set the frame's size and location, and make it visible
    setSize(300, 100);
    setLocationRelativeTo(null);
    setVisible(true);
  }

  public static void main(String[] args) {
    new MilesToKilometersConverter();
  }
}
