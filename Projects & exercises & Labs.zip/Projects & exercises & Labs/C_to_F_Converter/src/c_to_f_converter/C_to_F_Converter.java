package c_to_f_converter;       
 
import javax.swing.*; 
import java.awt.event.*;

public class C_to_F_Converter extends JFrame {
private JPanel panel1; 
private JLabel msgLabel;
private JTextField TextField; 
final int WINDOW_WIDTH = 310; 
final int WINDOW_HEIGHT = 100; 
int Cntr = 0;

public C_to_F_Converter() {
setTitle("C to F Converter");
setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
buildPanel();
add(panel1);
setLocationRelativeTo(null);
setVisible(true);
}
private void buildPanel(){
    
panel1 = new JPanel();
msgLabel = new JLabel("Calculate Celsius to fahrinhite");

TextField = new JTextField(10);



////////////////////
JButton calculateButton = new JButton("Calculate");
calculateButton.addActionListener(new CountButtonListener());

////////////////////
panel1.add(msgLabel); 
panel1.add(TextField); 
panel1.add(calculateButton);
} 
private class CountButtonListener implements ActionListener{
    
    public void actionPerformed(ActionEvent e) {
        double Fahr;
        String input;
        input=TextField.getText();
        Fahr = ((Double.parseDouble(input) * (9/5)) + 32);
        JOptionPane.showMessageDialog(null,input + " Celsius" + " is: " + Fahr + "F");
        

}
}
public static void main(String[] args) {
    
C_to_F_Converter kiloConv1 = new C_to_F_Converter(); 

    }
}
