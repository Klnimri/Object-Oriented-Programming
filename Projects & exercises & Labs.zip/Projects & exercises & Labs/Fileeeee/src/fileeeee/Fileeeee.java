
package fileeeee;

import java.util.*;
import javax.swing.*;
import java.io.*;

public class Fileeeee {

    
    public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Please enter the File's name: ");
        String FileName= input.nextLine(); // getting the file's name.
        
        File file = new File(FileName);
        Scanner InputFile = new Scanner (file);
        String FirstLine = InputFile.nextLine();
        
        System.out.println("The first line of the txt is.");
        System.out.println(FirstLine);
        
        InputFile.close();
        
        
        
        
        
    }
    
}
