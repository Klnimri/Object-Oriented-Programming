import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ChessGame extends JFrame {
  // Constants for the chess board size
  private static final int ROWS = 8;
  private static final int COLUMNS = 8;

  // 2D array to represent the chess board
  private JButton[][] board;

  // Variable to store the selected piece
  private JButton selectedPiece;

  // Constructor
  public ChessGame() {
    // Set the frame's title
    setTitle("Chess Game");

    // Set the layout to GridLayout
    setLayout(new GridLayout(ROWS, COLUMNS));

    // Create the chess board
    board = new JButton[ROWS][COLUMNS];
    for (int row = 0; row < ROWS; row++) {
      for (int col = 0; col < COLUMNS; col++) {
        // Create a button for the chess square
        JButton button = new JButton();
        board[row][col] = button;

        // Set the button's background color based on its position on the board
        if ((row + col) % 2 == 0) {
          button.setBackground(Color.WHITE);
        } else {
          button.setBackground(Color.BLACK);
        }

        // Set the button's icon based on its position on the board
        ImageIcon icon = null;
        if (row == 0 || row == 7) {
          // Pawns or rooks
          if (col == 0 || col == 7) {
            icon = new ImageIcon("rook.png");
          } else if (col == 1 || col == 6) {
            icon = new ImageIcon("knight.png");
          } else if (col == 2 || col == 5) {
            icon = new ImageIcon("bishop.png");
          } else if (col == 3) {
            icon = new ImageIcon("queen.png");
          } else if (col == 4) {
            icon = new ImageIcon("king.png");
          }
        } else if (row == 1 || row == 6) {
          // Pawns
          icon = new ImageIcon("pawn.png");
        }
        button.setIcon(icon);

        // Add an action listener to the button
        button.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
            // If a piece is selected, move it to the clicked square
            if (selectedPiece != null) {
              // Remove the icon from the selected piece
              selectedPiece.setIcon(null);
              // Set the icon of the clicked square to the selected piece's icon
              button.setIcon(selectedPiece.getIcon());
              // Clear the selected piece
              selectedPiece = null;
            } else {
              // Select the clicked piece
              selectedPiece = button;
            }
          }
        });

        // Add the button to the frame
        add(button);
      }
    }

    // Set the frame's size and location, and make it visible
    setSize(400, 400);
      setVisible(true);

  }

  public static void main(String[] args) {
    new ChessGame();
  }
}
