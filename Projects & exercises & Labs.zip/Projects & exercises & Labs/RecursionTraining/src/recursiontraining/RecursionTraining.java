
package recursiontraining;

public class RecursionTraining
{

    
    public static void main(String[] args)
    {
        int[] a = new int[15];
        for(int i = 0; i<15;i++){
            a[i]=i+1;
        }
        
        
        System.out.println("the sum of the array is: "+rangeSum(a, 0, 14));
        System.out.println("the factorial of 7 is: "+ factorial(7));
        System.out.println("the fibonacci number 8 is: " + Fib(8));
    }
    
    
  
    
    private static int Fib(int n){
      if(n==0){
          return 0;
      }
      else if (n==1){
          return 1;
      }
      else {
          return Fib(n-1)+Fib(n-2);
      }
}
    private static int factorial(int n){
     if(n==0){
         return 1;
     }
     else{
         return n * factorial(n-1);
     }
        
        
}
    public static int rangeSum(int[] array, int start , int end){
     if (start > end){
         return 0;
     }
     else {
         return array[start] + rangeSum(array, start+1, end);
     }
        
        
}
    
    
    
    
    
    
    
}
