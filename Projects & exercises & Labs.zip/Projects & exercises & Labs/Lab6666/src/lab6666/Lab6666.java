/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab6666;

/**
 *
 * @author klnimri
 */
public class Lab6666 {

    public static void main(String[] args) {
    Average a1 = new Average();
    
    }
    
}
