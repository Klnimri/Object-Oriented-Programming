/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab6666;

import java.util.*;

public class Average {
   private int data[] = new int[5];
   private double mean;
   
   public Average(){
       Scanner input = new Scanner(System.in);
       for (int i=0 ;i<data.length ;i++){
       System.out.print("Please enter the the scores");
       data[i]=input.nextInt();
       }
       calculateMean();
       
   }
   
   public void calculateMean(){
       int total = 0;
       for (int x =0; x<data.length;x++){
           total=+ data[x];
       }
       mean= ((double)total/data.length);
       System.out.println(mean);
   }
   public String toString(){
     return String.format("The mean is:"+mean);  
   }
   
}

