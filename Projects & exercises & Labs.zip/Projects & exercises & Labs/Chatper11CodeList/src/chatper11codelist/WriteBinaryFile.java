/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatper11codelist;

/**
 *
 * @author Shahzad Saleem
 */
import java.io.*;

/**
 * This program opens a binary file and writes the contents of an int array to
 * the file.
 */
public class WriteBinaryFile {

    public static void main(String[] args)
            throws IOException {
        // An array to write to the file
        int[] numbers = {2, 4, 6, 8, 10, 12, 14};
        // Create the binary output objects.
        FileOutputStream fstream
                = new FileOutputStream("Numbers.dat");
        DataOutputStream outputFile
                = new DataOutputStream(fstream);
        System.out.println("Writing the numbers to the file...");
        // Write the array elements to the file.
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("Going to write: "+numbers[i]);
            outputFile.writeInt(numbers[i]);
        }
        System.out.println("Done.");
        // Close the file.
        outputFile.flush();
        outputFile.close();
    }
}
