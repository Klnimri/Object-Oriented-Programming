/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatper11codelist;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Shahzad Saleem
 */
public class OpenFile {

    public static void main(String[] args) {
        // TODO code application logic here
        
        try {
            File file = new File("MyFile.txt");
            System.out.println(file);
            Scanner inputFile = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.out.println("Sorry, MyFile.txt not found.\n");
            e.printStackTrace();
        }

        PrintWriter outputFile;
        try {
            outputFile = new PrintWriter("Number.txt");
            int x = 1297;
            outputFile.print(x);
            outputFile.flush();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(OpenFile.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /*
// This method will not compile!
public void displayFile(String name) {
        // Open the file.
        File file = new File(name);
        Scanner inputFile = new Scanner(file);
        // Read and display the file's contents.
        while (inputFile.hasNext()) {
            System.out.println(inputFile.nextLine());
        }
        // Close the file.
        inputFile.close();
    }
     */
}
