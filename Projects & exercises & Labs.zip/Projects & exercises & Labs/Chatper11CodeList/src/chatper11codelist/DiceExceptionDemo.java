/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatper11codelist;

/**
 *
 * @author Shahzad Saleem
 */
/**
 * This program demonstrates how the Dice class throws an exception when an
 invalid value is passed to the constructor.
 */
public class DiceExceptionDemo {

    public static void main(String[] args) {
        final int DIE_SIDES = 3; // Number of sides

        // Create an instance of the Dice class.
        Dice dice = new Dice(DIE_SIDES);

        System.out.println("Initial value of the dice:");
        System.out.println(dice.getValue());
        dice.roll();
        System.out.println("Value of the dice after rolling:");
        System.out.println(dice.getValue());
    }
}
