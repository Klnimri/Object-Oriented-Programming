/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatper11codelist;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 *
 * @author Shahzad Saleem
 */
public class WriteAndReadUTF {
    public static void main(String[] args) throws Exception {
        FileOutputStream fos = new FileOutputStream("UTF String");
        DataOutputStream dos = new DataOutputStream(fos);
        dos.writeUTF("Hello, World!");
        dos.writeUTF("Hello, World!");
        dos.writeUTF("Hello, World!");
        dos.writeUTF("Hello, World!");
        dos.flush();
        dos.close();
       
        
        System.out.println("Bytes Written are = ");
        
        // Attempt to decode the bytes back into a String
        //byte[] byteBuffer = fos.toByteArray();
        FileInputStream fis = new FileInputStream("UTF String");
        DataInputStream dis = new DataInputStream(fis);
        while(true){
            try{
                System.out.println(dis.readUTF());
            }catch(EOFException eof){
                break;
            }
        }
    }
}
