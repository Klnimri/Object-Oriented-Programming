/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatper11codelist;

/**
 *
 * @author Shahzad Saleem
 */
/**
 * /**
 * NegativeStartingBalance exceptions are thrown by the BankAccount class when a
 * negative starting balance is passed to the constructor.
 */
public class NegativeStartingBalance
        extends Exception {

    /**
     * This constructor uses a generic error message.
     */
    public NegativeStartingBalance() {
        super("Error: Negative starting balance");
    }

    /**
    This constructor sets the starting balance
    to the value passed as an argument.
    @param startBalance The starting balance.
    @exception NegativeStartingBalance When
    startBalance is negative.
    */

    public NegativeStartingBalance(double amount) {
        super("Error: Negative starting balance: "
                + amount);

    }
}
