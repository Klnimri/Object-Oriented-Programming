/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatper11codelist;

/**
 *
 * @author Shahzad Saleem
 */
/**
 * This program demonstrates how the BankAccount class constructor throws custom
 * exceptions.
 */
public class AccountTest {

    public static void main(String[] args) {
        // Force a NegativeStartingBalance exception.
        try {
            BankAccount account = new BankAccount(-100.0);
        } catch (NegativeStartingBalance e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }
}
