
package hfmeals;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public
        class MainPage extends JFrame{
   
    JPanel MainPanel;
    JButton NewCustomerButton;
    JLabel Welcome;
    static NewCustomer ww;
    
    public MainPage(){
        setTitle("HF meals");
        setBackground(Color.lightGray);
        setLayout(new BorderLayout(10,10));
        Font font = new Font("Monospaced", Font.BOLD, 12);
        setFont(font);
        setSize(950,120);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        buildPanel();
        
        
        setVisible(true);
    }
    
    public void buildPanel(){
        MainPanel = new JPanel();
       
        
        NewCustomerButton = new JButton("New Customer");
        NewCustomerButton.addActionListener(new ActionListener() {
            
            public
            void actionPerformed(ActionEvent e) {
                setVisible(false);
                ww = new NewCustomer();
            }
        });
        
        Welcome = new JLabel("Welcome to HF meals here we provide you the healthy food delivary service"
                + " you can proceed by creating an account from the button below.");
       
        
        MainPanel.add(Welcome);
        MainPanel.add(NewCustomerButton);
        
        
        add(new JPanel(),BorderLayout.NORTH);
        add(new JPanel(),BorderLayout.SOUTH);
        add(new JPanel(),BorderLayout.EAST);
        add(new JPanel(),BorderLayout.WEST);
        add(MainPanel,BorderLayout.CENTER);
    }
}
