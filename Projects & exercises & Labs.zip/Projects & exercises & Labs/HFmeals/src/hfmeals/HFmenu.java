
package hfmeals;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public
        class HFmenu extends JFrame{
    JPanel LeftMealsPanel;
    JPanel LeftDrinksPanel;
    JPanel LeftRightPanel;
    JPanel RightPanel;
    static JCheckBox Meal1Meat;
    static JCheckBox Meal2Chicken;
    static JCheckBox Meal3Fish;
    static JCheckBox Meal4Vegan;
    static JCheckBox Drink1;
    static JCheckBox Drink2;
    JTextArea Bag;
    JButton ClearButton;
    JButton CheckOutButton;
    static int Meal1MeatCounter = 0;
    static int Meal2ChickenCounter = 0;
    static int Meal3FishCounter = 0;
    static int Meal4VeganCounter = 0;
    static int Drink1Counter = 0;
    static int Drink2Counter = 0;
    static int TotalPrice = 0;
    
    
    
    public HFmenu(){
     
        setTitle("HF Menu");
        setBackground(Color.lightGray);
        setLayout(new BorderLayout(10,10));
        Font font = new Font("Monospaced", Font.BOLD, 12);
        setFont(font);
        setSize(1100,580);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        buildLeftPanel();
        buildRightPanel();
        
        
        setVisible(true);
    }
    public void buildLeftPanel(){
        
        LeftMealsPanel = new JPanel();
        LeftDrinksPanel = new JPanel();
        LeftMealsPanel.setLayout(new GridLayout(4, 1));
        LeftDrinksPanel.setLayout(new GridLayout(2, 1));
        LeftMealsPanel.setBorder(BorderFactory.createTitledBorder("Meals"));
        LeftDrinksPanel.setBorder(BorderFactory.createTitledBorder("Drinks"));
        
           
        
        Meal1Meat = new JCheckBox("1. 200G of meet with 100G of rice and 50G of pasta and salad&snacks");
        Meal2Chicken = new JCheckBox("2. 200G of grilled Chicken with 130G of rice with mushroom sauce and snacks");
        Meal3Fish = new JCheckBox("3. 200G of fried salmon fish and tuna with 100G of rice and sauces and salad&snacks");
        Meal4Vegan = new JCheckBox("4. 100G of beans with rice and 100G of salad&Vegetarian snacks");
        
        Drink1 = new JCheckBox("Diet Pepsi");
        Drink2 = new JCheckBox("Diet 7up");
        
        Meal1Meat.addItemListener(new ItemListener() {
            
            public
            void itemStateChanged(ItemEvent e) {
                if(Meal1Meat.isSelected()){
                Meal1MeatCounter++;
                Bag.append("");
                Bag.append(Meal1MeatCounter+"."+" 200G of meet with 100G of rice and 50G of pasta and salad&snacks 32SAR\n");
                TotalPrice+=32*Meal1MeatCounter;
                }
                else return;
            }   
        });
        Meal2Chicken.addItemListener(new ItemListener() {
           
            public
            void itemStateChanged(ItemEvent e) {
                if(Meal2Chicken.isSelected()){
                Meal2ChickenCounter++;
                Bag.append(Meal2ChickenCounter+"."+" 200G of grilled Chicken with 130G of rice with mushroom sauce and snacks 30SAR\n");
                TotalPrice+=30*Meal2ChickenCounter;
                }
                else return;
            }
        });
        
        Meal3Fish.addItemListener(new ItemListener() {
            
            public
            void itemStateChanged(ItemEvent e) {
                if(Meal3Fish.isSelected()){
                Meal3FishCounter++;
                Bag.append(Meal3FishCounter+"."+" 200G of fried salmon fish and tuna with 100G of rice and sauces and salad&snacks 32SAR\n");
                TotalPrice+=32*Meal3FishCounter;
                }
                else return;
            }
        });
        
        Meal4Vegan.addItemListener(new ItemListener() {
            
            public
            void itemStateChanged(ItemEvent e) {
                if(Meal4Vegan.isSelected()){
                Meal4VeganCounter++;
                Bag.append(Meal4VeganCounter+"."+" 100G of beans with rice and 100G of salad&Vegetarian snacks 28SAR\n");
                TotalPrice+=28*Meal4VeganCounter;
                }
                else return;
            }
        });
        
        Drink1.addItemListener(new ItemListener() {
            
            public
            void itemStateChanged(ItemEvent e) {
                if(Drink1.isSelected()){
                Drink1Counter++;
                Bag.append(Drink1Counter+"."+" Diet Pepsi\t\t3SAR\n");
                TotalPrice+=3*Drink1Counter;
                }
                else return;
            }
        });
        
        Drink2.addItemListener(new ItemListener() {
            
            public
            void itemStateChanged(ItemEvent e) {
                if(Drink2.isSelected()){
                Drink2Counter++;
                Bag.append(Drink2Counter+"."+" Diet 7up\t\t3SAR\n");
                TotalPrice+=3*Drink2Counter;
                }
                else return;
            }
        });
        
        LeftMealsPanel.add(Meal1Meat);
        LeftMealsPanel.add(Meal2Chicken);
        LeftMealsPanel.add(Meal3Fish);
        LeftMealsPanel.add(Meal4Vegan);
        
        LeftDrinksPanel.add(Drink1);
        LeftDrinksPanel.add(Drink2);
        
        LeftRightPanel = new JPanel();
        LeftRightPanel.setLayout(new BorderLayout(10, 10));
        LeftRightPanel.add(LeftMealsPanel,BorderLayout.NORTH);
        LeftRightPanel.add(LeftDrinksPanel,BorderLayout.SOUTH);
        
        add(LeftRightPanel,BorderLayout.WEST);
        
    }
    public void buildRightPanel(){
        
        RightPanel = new JPanel();
        RightPanel.setLayout(new BorderLayout(10,10));
        Bag = new JTextArea("ADD TO BAG\n");
        Font font = new Font("Monospaced", Font.BOLD, 12);
        Bag.setFont(font);
        
        ClearButton = new JButton("Clear");
        ClearButton.addActionListener(new ActionListener() {
            
            public
            void actionPerformed(ActionEvent e) {
                
                Bag.setText("");
                TotalPrice=0;
                Meal1MeatCounter=0;
                Meal2ChickenCounter=0;
                Meal3FishCounter=0;
                Meal4VeganCounter = 0;
                Drink1Counter=0;
                Drink2Counter=0;
                
            }
        });
        
        CheckOutButton = new JButton("Checkout");
        CheckOutButton.addActionListener(new ActionListener() {
            
            public
            void actionPerformed(ActionEvent e) {
                setVisible(false);
                Bill u = new Bill();
            }
        });
        
        
        RightPanel.add(Bag, BorderLayout.CENTER);
        RightPanel.add(ClearButton, BorderLayout.EAST);
        RightPanel.add(CheckOutButton, BorderLayout.SOUTH);
        
        
        add(RightPanel,BorderLayout.CENTER);
        
        
        
    }
   
}
