
package hfmeals;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public
        class NewCustomer extends JFrame {
    
    JPanel newCustomerPanel;
    JLabel CustomerFullNamelabel;
    JLabel CustomerPhoneNumberLabel;
    JLabel CustomerCityLabel;
    JLabel CustomerAddressLabel;
    JLabel CustomerWeightLabel;
    JLabel CustomerHeightLabel;
    String CustomerPhoneNumberString;
    double CustomerPhoneNumberDouble;
    
    static JTextField CustomerFullNameText;
    static JTextField CustomerPhoneNumberText;
    static JTextField CustomerCityText;
    static JTextField CustomerAddressText;
    static JTextField CustomerWeightText;
    static JTextField CustomerHeightText;
    
    JButton OkButton;
    static HFmenu t;
    
    public NewCustomer(){
        
        setTitle("New Customer");
        setBackground(Color.lightGray);
        setLayout(new BorderLayout(10,10));
        Font font = new Font("Monospaced", Font.BOLD, 12);
        setFont(font);
        setSize(230,260);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        BuildPanel();
        
        setVisible(true);
    }
    
    public void BuildPanel(){
        newCustomerPanel = new JPanel();
        newCustomerPanel.setSize(180,100);
        newCustomerPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        
        CustomerFullNamelabel = new JLabel("Full name");
        
        
        CustomerFullNameText = new JTextField(10);
        CustomerPhoneNumberLabel = new JLabel("Phone number");
        CustomerPhoneNumberText = new JTextField(10);
        
        CustomerCityLabel = new JLabel("City");
        CustomerCityText = new JTextField(10);
        CustomerAddressLabel = new JLabel("    Address");
        CustomerAddressText = new JTextField(10);
        CustomerWeightLabel = new JLabel("Weight");
        CustomerWeightText = new JTextField(10);
        CustomerHeightLabel = new JLabel("    Height");
        CustomerHeightText = new JTextField(10);
        
        newCustomerPanel.add(CustomerFullNamelabel);
        newCustomerPanel.add(CustomerFullNameText);
        newCustomerPanel.add(CustomerPhoneNumberLabel);
        newCustomerPanel.add(CustomerPhoneNumberText);
        newCustomerPanel.add(CustomerCityLabel);
        newCustomerPanel.add(CustomerCityText);
        newCustomerPanel.add(CustomerAddressLabel);
        newCustomerPanel.add(CustomerAddressText);
        newCustomerPanel.add(CustomerWeightLabel);
        newCustomerPanel.add(CustomerWeightText);
        newCustomerPanel.add(CustomerHeightLabel);
        newCustomerPanel.add(CustomerHeightText);
        
        OkButton = new JButton("OK");
        OkButton.addActionListener(new ActionListener() {
            
            public
            void actionPerformed(ActionEvent e) {
                ////////////////////////////////////////////////////////////
              CustomerPhoneNumberString = CustomerPhoneNumberText.getText();
              CustomerPhoneNumberDouble = Double.parseDouble(CustomerPhoneNumberString);
              while(CustomerPhoneNumberDouble < 0 || CustomerPhoneNumberDouble > (double)1111111111)
              {
                CustomerPhoneNumberString = JOptionPane.showInputDialog(null, "Wrong phone number entery");
                CustomerPhoneNumberDouble = Double.parseDouble(CustomerPhoneNumberString);
              }
               /////////////////////////////////////////////////////////////
                setVisible(false);
                t = new HFmenu();
              }
            
        });
        
        
        add(newCustomerPanel,BorderLayout.CENTER);
        add(OkButton,BorderLayout.SOUTH);
        
        }
    }

