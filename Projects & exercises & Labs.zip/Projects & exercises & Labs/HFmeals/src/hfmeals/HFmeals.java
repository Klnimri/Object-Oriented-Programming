
package hfmeals;


public
        class HFmeals {

    static MainPage a ;
    public static
            void main(String[] args) {
                a = new MainPage();
            }
    
}
