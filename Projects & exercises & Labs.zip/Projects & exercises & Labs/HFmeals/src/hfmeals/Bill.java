
package hfmeals;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.logging.*;
import javax.swing.*;


public
        class Bill extends JFrame {
    JPanel AreaPanel;
    JTextArea Bill;
    JButton FileChooserButton = new JButton("Browse");
    JFileChooser FileChooser;
    int status;
    
    
    
    public Bill(){
        setTitle("HF Bill");
        setBackground(Color.lightGray);
        setLayout(new BorderLayout(10,10));
        Font font = new Font("Monospaced", Font.BOLD, 12);
        setFont(font);
        setSize(1100,580);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        buildAreaPanel();
        Bill.setEditable(false);
        
        
        
        FileChooserButton.setToolTipText("Click here to choose a file to save in \"Txt\"");
        FileChooserButton.addActionListener(new ActionListener() {
            public
            void actionPerformed(ActionEvent e) {
                FileChooser = new JFileChooser();
                FileChooser.showSaveDialog(FileChooserButton);
                
                if (status == JFileChooser.APPROVE_OPTION){
                    File selectedFile = FileChooser.getSelectedFile();
                    String FileName = selectedFile.getPath();
                    try
                    {
                        FileWriter fw = new FileWriter(FileName);
                        PrintWriter OutPutFile = new PrintWriter(fw);
                        OutPutFile.println("\t\t    Recipt");
                        OutPutFile.println("---------------------------------------------");
                        if(NewCustomer.CustomerFullNameText != null){
                        OutPutFile.println("Customer Fullname: "+NewCustomer.CustomerFullNameText.getText());
                        }
                        if(NewCustomer.CustomerPhoneNumberText != null){
                        OutPutFile.println("Customer Phone number: "+NewCustomer.CustomerPhoneNumberText.getText());
                        }
                        if(NewCustomer.CustomerCityText != null){
                        OutPutFile.println("Customer City: "+NewCustomer.CustomerCityText.getText());
                        }
                        if(NewCustomer.CustomerAddressText != null){
                        OutPutFile.println("Customer Address: "+NewCustomer.CustomerAddressText.getText()); 
                        }
                        OutPutFile.println("---------------------------------------------");
                        if(HFmenu.Meal1Meat.isSelected()){
                        OutPutFile.println("");
                        OutPutFile.println(HFmenu.Meal1MeatCounter+"."+" 200G of meet with 100G of rice and 50G of pasta and salad&snacks 32SAR\n");
                        }
                        if(HFmenu.Meal2Chicken.isSelected()){
                        OutPutFile.println(HFmenu.Meal2ChickenCounter+"."+" 200G of grilled Chicken with 130G of rice with mushroom sauce and snacks 30SAR\n");
                        }
                        if(HFmenu.Meal3Fish.isSelected()){
                        OutPutFile.println(HFmenu.Meal3FishCounter+"."+" 200G of fried salmon fish and tuna with 100G of rice and sauces and salad&snacks 32SAR\n");
                        }
                        if(HFmenu.Meal4Vegan.isSelected()){
                        OutPutFile.println(HFmenu.Meal4VeganCounter+"."+" 100G of beans with rice and 100G of salad&Vegetarian snacks 28SAR\n");
                        }
                        if(HFmenu.Drink1.isSelected()){
                        OutPutFile.println(HFmenu.Drink1Counter+"."+" Diet Pepsi\t\t3SAR\n");
                        }
                        if(HFmenu.Drink2.isSelected()){
                        OutPutFile.println(HFmenu.Drink2Counter+"."+" Diet 7up\t\t3SAR\n");
                        }
                        OutPutFile.println("The total is: "+HFmenu.TotalPrice + " SAR");
            
                        OutPutFile.close();
                    }
                    catch (IOException ex)
                    {
                        Logger.getLogger(Bill.class.getName()).
                                log(Level.SEVERE, null, ex);
                    }
                }
            }
        });
        
        setVisible(true);
        
    }
    public void buildAreaPanel(){
        AreaPanel = new JPanel();
        Bill = new JTextArea("\t\t    Recipt\n");
            
             if(HFmenu.Meal1Meat.isSelected()){
             Bill.append("");
             Bill.append(HFmenu.Meal1MeatCounter+"."+" 200G of meet with 100G of rice and 50G of pasta and salad&snacks 32SAR\n");
                 }
             else {
                
            }

            if(HFmenu.Meal2Chicken.isSelected()){
            Bill.append(HFmenu.Meal2ChickenCounter+"."+" 200G of grilled Chicken with 130G of rice with mushroom sauce and snacks 30SAR\n");
            }
            else{
                
            }
         
            if(HFmenu.Meal3Fish.isSelected()){
            Bill.append(HFmenu.Meal3FishCounter+"."+" 200G of fried salmon fish and tuna with 100G of rice and sauces and salad&snacks 32SAR\n");
            }
            else {
                
            }
            
            if(HFmenu.Meal4Vegan.isSelected()){
            Bill.append(HFmenu.Meal4VeganCounter+"."+" 100G of beans with rice and 100G of salad&Vegetarian snacks 28SAR\n");
            }
            else {
                
            }
           
            if(HFmenu.Drink1.isSelected()){
            Bill.append(HFmenu.Drink1Counter+"."+" Diet Pepsi\t\t3SAR\n");
            }
            else {
                
            }
            
            if(HFmenu.Drink2.isSelected()){
            Bill.append(HFmenu.Drink2Counter+"."+" Diet 7up\t\t3SAR\n");
            }
            else {
                
            }
            Bill.append("The total is: "+HFmenu.TotalPrice + " SAR");
            
        
        AreaPanel.add(Bill,BorderLayout.CENTER);
        add(AreaPanel,BorderLayout.CENTER);
        add(FileChooserButton,BorderLayout.SOUTH);
    }
}
