/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package televisiondemo;

import java.util.*;
public class Television {
    
    private final String MANUFACTURER;                         //The Manufacturer of the television for example: Toshiba, Sony,... 
    private final int SCREEN_SIZE;                             //The size of the screen in inches.
    private boolean powerOn;                             //Turning the TV on or off.
    private int channel;                                 //Channel number.
    private int volume;                                  //Volume level.
       
    Television(String brand, int size){                  //Constructor.
        MANUFACTURER = brand;                            //assigning the value of the parameter to the variable .
        SCREEN_SIZE = size;                              //assigning the value of the parameter to the variable .
        powerOn = false;                                 //assigning the value of "powerOn" to false.
        volume = 20;                                     //intiallizing volume to 20.
        channel = 20;
        
        
    }
    
    public void setChannel(int station){
        channel = station;
    }
     public void power(){
        powerOn = true;
    }
     public void increaseVolume(){
        volume +=2; 
    }
     public void decreaseVolume(){
        volume -=2;
        
    }
     public int getChannel(int x){
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter the number of the channel: ");
        x = input.nextInt();
        return x;
        
    }
     public int getVolume(int v){
         Scanner input = new Scanner(System.in);
        System.out.print("Please enter the wanted volume level: ");
        v = input.nextInt();
        return v;
    }
      public String getManufacturer(){
        return this.MANUFACTURER;
    }
       public int getScreenSize(){
        return this.SCREEN_SIZE;
    }
}
