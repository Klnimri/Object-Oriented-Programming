/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simple;

public class Simple
{
    
    public static void main(String[] args){
        
        System.out.println("MyNameIs\tKhalid\tNimri\n");
        System.out.println("Im\t20Years old");
        
    }
  
    
}