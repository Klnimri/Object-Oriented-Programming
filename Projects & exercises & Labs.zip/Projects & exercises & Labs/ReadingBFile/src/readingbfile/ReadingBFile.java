
package readingbfile;

import javax.swing.*;
import java.io.*;
import java.util.*;



public class ReadingBFile {

    
    
    public static void main(String[] args) throws IOException  {
        
       try{
        FileInputStream Fread = new FileInputStream("Lab1.dat");
        DataInputStream inputFile = new DataInputStream(Fread);
        boolean endOfFile = false;
        while(!endOfFile){
       try{
          int number = inputFile.readInt();
           System.out.println(number);
       }
       catch (EOFException e){
           endOfFile = true;
       }
       
   }
    System.out.println("Done");
    inputFile.close();
    }
       catch(FileNotFoundException e){
           System.out.println("File not found");
    }
        }
   
    
}
