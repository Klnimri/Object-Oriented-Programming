package lab3232;

import java.util.Scanner;
import java.io.File;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.IOException;
public class Lab3232 {


    // TASK #1 Add the throws clause  
    public static void main(String[] args) throws IOException {
        
        //------------------------------------------------------------
        double sum = 0;	// The sum of the numbers 
        int count = 0;	// The number of numbers added 
        double mean = 0;	// The average of the numbers 
        double stdDev = 0;   // The standard deviation 
        String line;	// To hold a line from the file 
        double difference;   // The value and mean difference 
        //------------------------------------------------------------
        
        // Create an object of type Scanner 
        Scanner keyboard = new Scanner(System.in);
        String filename;	// The user input file name 
        
        //------------------------------------------------------------

        // Prompt the user and read in the file name 
        System.out.println("This program calculates "
                + "statistics on a file " + "containing a series of numbers");
        System.out.print("Enter the file name:  ");
        filename = keyboard.nextLine();

        //------------------------------------------------------------ TASK 2
        
	// ADD LINES FOR TASK #2 HERE 
        // Create a File object passing it the filename 
        File file = new File(filename);
        // Create a Scanner object passing File object
        Scanner input = new Scanner(file);
        // Perform a priming read to read the first line of  the file 
        line = input.nextLine();
        // Loop until you are at the end of the file 
        while(input.hasNext()){
        // Add value to sum 
         sum+= Double.parseDouble(line);
        // Increment the counter 
        count++;
        // Read a new line from the file 
        line = input.nextLine();
        }
        // Close the input file 
        input.close();
        // Store the calculated mean
        mean = sum / count;
        
        
        //------------------------------------------------------------ TASK 3
        
	// ADD LINES FOR TASK #3 HERE 
        // Reconnect File object passing it the filename
        file = new File(filename);
        // Reconnect Scanner object passing File object
        input = new Scanner(file);
        // Reinitialize the sum of the numbers 
        sum = 0;
        // Reinitialize the number of numbers added 
        count = 0;
        // Perform a priming read to read the first line of the file 
        line =  input.nextLine();
        // Loop until you are at the end of the file 
        while(input.hasNext()){
            
        // subtract the mean 
        difference = Double.parseDouble(line) - mean;
        // Add the square of the difference to the sum 
        sum += difference * difference;
        // Increment the counter
        count++;
        // Read a new line from the file 
        line =  input.nextLine();
        }
        // Close the input file 
        input.close();
        // Store the calculated standard deviation  
        stdDev = Math.sqrt(sum / count);

        //------------------------------------------------------------ TASK 1
        
        // ADD LINES FOR TASK #1 HERE 
        // Create a FileWriter object using "Results.txt" 
        FileWriter Writer = new FileWriter (new File("Results.txt"));
        // Create a PrintWriter object passing the FileWriter object 
        PrintWriter PrintWriter = new PrintWriter(Writer);
        // Print the results to the output file 
        PrintWriter.printf("mean of %.3f and div ",mean,stdDev );
        // Close the output file 
        PrintWriter.close();
    }
}