/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package methods;

import java.util.*; // so you can use the scanner mathod if wanted!
import javax.swing.*; // so you can use the JOptionPane Method if wanted
import java.io.*; // So you can use the File method if wanted!

public class Methods { 

    
    public static void main(String[] args) throws IOException { // Main method with an exception for the files if wanted.
        
     Scanner input = new Scanner(System.in); // Creating a scanner object to use later.
     System.out.println("Hello there!\nWelcome to the Calculator!"); // Greating!
     System.out.print("Please enter the first value: "); // Getting the FirstValue from the user.
     int FirstValue = input.nextInt(); // Taking and storing the value to the FirstValue variable.
     
     System.out.print("Please enter the second value: "); // Taking the second value from teh user.
     int SecondValue= input.nextInt(); // Taking and Stroing the value to the Secondvalue variable.
     System.out.println("\n");// Formating by printing two empty lines.
     System.out.println("The Addition of "+ FirstValue + " and " + SecondValue + " is " + Addition(FirstValue, SecondValue));
     System.out.println("The Subtraction of "+ FirstValue + " and " + SecondValue + " is " + Subtraction(FirstValue, SecondValue));
     System.out.println("The Multiplication of "+ FirstValue + " and " + SecondValue + " is " + Multiplication(FirstValue, SecondValue));
     System.out.println("The Division of "+ FirstValue + " and " + SecondValue + " is " + Division(FirstValue, SecondValue));
     System.out.println("The Reminder of "+ FirstValue + " and " + SecondValue + " is " + Reminder(FirstValue, SecondValue));

        
    }
    
    public static int Addition(int x, int y){
        
        int sum = x + y;
        return sum;
       
    }
    public static int Subtraction (int x, int y){
        return x-y;
        
    }
    
    public static int Multiplication(int x, int y){
        return x*y;
    }
    
    public static double Division(double x, double y){
        return x/y;
    }
    
    public static double Reminder(double x, double y){
        return x%y;
    }
}