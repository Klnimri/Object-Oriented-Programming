/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chapter4exersice;

import java.util.*;
import javax.swing.*;

public class Chapter4Exersice {

    
    
    public static void main(String[] args) {

        int Points;
        int TotalPoints = 1;
        String StrPoints =JOptionPane.showInputDialog(" Please enter the number of points your team has got, enter -1 to end.");
        Points = Integer.parseInt(StrPoints);
        
        TotalPoints += Points;
         
         
        while (Points != -1){
            
        StrPoints =JOptionPane.showInputDialog(" Please enter the number of points your team has got, enter -1 to end.");
        Points = Integer.parseInt(StrPoints);
        TotalPoints += Points;
         
        }
        
        JOptionPane.showMessageDialog(null, "Total points are: "+ TotalPoints);
        System.exit(0);
    }
    
    
}
