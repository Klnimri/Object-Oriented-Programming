/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ifelsetry;

import java.util.*;
import javax.swing.*;

public class IfElseTry {

    public static void main(String[] args) {
        
        int x,y;
        
        Scanner input = new Scanner(System.in);
        
       System.out.print("Please enter the value of x: ");
        x= input.nextInt();
        System.out.print("Please enter the value of Y: ");
        y= input.nextInt();
        
        if (x > y){
            
            System.out.println("X is greater than Y.");
            
        }
        
        else if (x == y){
            System.out.println("X equals Y.");
            
        }
        else if (x < y){
            System.out.println("X is smaller than Y.");
            
        }
        
        else {
            System.out.println("There's an error during the debugging.");
        }
        System.exit(0);
    }
    
}
