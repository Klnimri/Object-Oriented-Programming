
package test1;         //Student name: khalid nimri
                       //Student ID: 2140145
import java.util.Scanner;

public class Test1 {
 
    public static void main(String[] args) {
       
        Scanner input =new Scanner(System.in);
        String psw ="123123";
        String UserInp;

        System.out.println("Please enter the password");
        UserInp=input.nextLine();
        
        if(UserInp.equals(psw)){
            System.out.println("The password is correct!");
        }
        else {
            System.out.println("The password is wrong!");
        }
   
    }
    
}
