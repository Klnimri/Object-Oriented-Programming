
package file1234;


import java.util.*;
import javax.swing.*;
import java.io.*;

public class File1234 {

   
    
    public static void main(String[] args) throws IOException {
        
        Scanner Input = new Scanner(System.in);
        System.out.print("Please enter the file's name: ");
        String FileName = Input.nextLine();
        
        File file = new File(FileName);
        Scanner InputFile = new Scanner(file);
        
        String FirstLine= InputFile.nextLine();
        
        System.out.println("The First Line of the txt is.");
        System.out.println(FirstLine);
        InputFile.close();
        System.exit(0);
    }
    
}
