import java.awt.*;                  //Student name: Khalid Nimri
import java.awt.event.ActionEvent;  //Student ID: 2140145
import java.awt.event.ActionListener;
import javax.swing.*;


public class Test2 {
    
// Main method
public static void main(String[] args) {
    
JFrame frame = new TempretureConverter(); // create a jframe

frame.setTitle("Tempreture Converter");
frame.setLocationRelativeTo(null);
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // close
frame.pack();
frame.setVisible(true);

}// end of main method

}

class TempretureConverter extends JFrame implements ActionListener {
// create a button
JButton btnCalculate = new JButton("Calculate");

// create a label
JLabel label1 = new JLabel("Celsius");
JLabel label2 = new JLabel("Fahrenhite");

// create radio button
JRadioButton rbtnCelsius = new JRadioButton("Celsius");
JRadioButton rbtnFahrenhite = new JRadioButton("Fahrenhite");

JLabel lblBlank = new JLabel("");

// create a textfield
JTextField txtCelsius = new JTextField(30);
JTextField txtFahrenhite = new JTextField(30);

JPanel panel;

public TempretureConverter() {
    
panel = new JPanel();
// create a grid layout to the pane
panel.setLayout(new GridLayout(4, 2));

// set the size to panel
panel.setPreferredSize(new Dimension(400, 200));

// Group the radio buttons.
ButtonGroup group = new ButtonGroup();
group.add(rbtnCelsius);
group.add(rbtnFahrenhite);

// compnents of the panel
panel.add(label1);
panel.add(txtCelsius);
panel.add(label2);
panel.add(txtFahrenhite);
panel.add(rbtnCelsius);
panel.add(rbtnFahrenhite);
panel.add(lblBlank);
panel.add(btnCalculate);
add(panel);

// create button listener
btnCalculate.addActionListener(this);
}

// action listener
@Override
public void actionPerformed(ActionEvent e) {
if (txtCelsius.getText().equals("") && txtFahrenhite.getText().equals("")) { 
//check for the blank celsius and fahrenhte textbox
JOptionPane.showMessageDialog(null, "Please enter value to convert.", "Error", JOptionPane.ERROR_MESSAGE);
} 
else if (txtCelsius.getText().equals("")) 
{ 
//check for the celcius textbox only blank
if (rbtnCelsius.isSelected()) 
{
double c = (Double.parseDouble(txtFahrenhite.getText()) - 32) * 0.55;
txtCelsius.setText(String.valueOf(c));
} 
else 
{
JOptionPane.showMessageDialog(null, "Please select Celsius", "Error", JOptionPane.ERROR_MESSAGE);
}

} 
else if (txtFahrenhite.getText().equals("")) 
{ 
//check for the fahrenhite textbox only blank
if (rbtnFahrenhite.isSelected()) 
{
double f = Double.parseDouble(txtCelsius.getText()) * 1.8 + 32;
txtFahrenhite.setText(String.valueOf(f));
} 
else 
{
JOptionPane.showMessageDialog(null, "Please select Fahrenhite", "Error", JOptionPane.ERROR_MESSAGE);
}
}
}
}