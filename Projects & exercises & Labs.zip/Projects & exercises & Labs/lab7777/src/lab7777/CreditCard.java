/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab7777;

import java.util.*;

public class CreditCard {
    
    private Money balance;
    private Money creditLimit;
    private Person owner;
    
    public CreditCard(Person newCardHolder, Money limit){
        owner=newCardHolder;
        creditLimit=limit; 
        balance=limit;
    }
    
    public Money getBalance()
    {
            return balance;
        }
    public Money getCreditLimit(){
        return new Money(creditLimit);
    }
    public String getPersonals(){
        return this.owner.toString();
    }
    public void charge(Money amount){ 
        if(balance.add(amount).compareTo(creditLimit)==-1){
        balance=balance.add(amount);
        System.out.println("Charge : "+amount.toString()); }else{
        System.out.println("exced credit limit"); }
    }
    public void payment(Money amount){
        balance=balance.subtract(amount);
        System.out.println("Payment"+amount.toString());
    }
    
    
    
}
