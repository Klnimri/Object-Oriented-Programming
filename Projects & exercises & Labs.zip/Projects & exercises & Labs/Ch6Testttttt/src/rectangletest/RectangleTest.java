
package rectangletest;

import java.util.*;
import javax.swing.*;
import java.io.*;

public class RectangleTest {

    
    public static void main(String[] args) throws FileNotFoundException {
        ////// Object creating
        RectangleTestDemo R1 = new RectangleTestDemo();
        RectangleTestDemo R2 = new RectangleTestDemo(11 , 20);
        
        
        ////// PrintWriting
        PrintWriter OutPutFile = new PrintWriter("Rectangle.txt");
        OutPutFile.println("R1's length and width and area are:\n" + R1.getLength() + '\n' + R1.getWidth() + '\n' + R1.getArea(R1) + "m^2");
        OutPutFile.println("R2's length and width and area are:\n" + R2.getLength() + '\n' + R2.getWidth() + '\n' + R2.getArea(R2) + "m^2");
        OutPutFile.close();
        
        ///// FileReading
        FileReader F1 = new FileReader("Rectangle.txt");
        Scanner PrintFile = new Scanner(F1);
        
        while(PrintFile.hasNextLine())
            System.out.println(PrintFile.nextLine());


    }
}
