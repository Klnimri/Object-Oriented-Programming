

package rectangletest;


public class RectangleTestDemo {
    
    private double length = 0;
    private double width = 0;
    
   public RectangleTestDemo(){
       length = 1;
       width = 1;
   }
   public RectangleTestDemo(double x , double y ){
       length = x;
       width = y;
   }
   public void setLength(double l){
       length = l;
   }
   public void setWidth(double w){
       width = w;
       
   }
   public double getLength(){
       return length;
   }
   public double getWidth(){
       return width;
   }
   public double getArea(RectangleTestDemo r){
       return length * width;
   }
        
    }


