package accounttest;
public class BankAccount {        // Student name: Khalid Nimri
                                  // Student ID: 2140145
    private double Balance;
    //////////////////////////////// Constructors.
    public BankAccount(){
        Balance = 100;
    }
    public BankAccount(double StartBalance){
        Balance = StartBalance;
    }
    public BankAccount(String string){
        Balance = Double.parseDouble(string);
    }
    ///////////////////////////////// Deposit methods.
    public void Deposit(double amount){
        Balance += amount;
    }
    public void Deposit(String string){
        Balance += Double.parseDouble(string);
    }
    //////////////////////////////// Withdraw methods.
    public void Withdraw(double amount){
        Balance -= amount;
    }
    public void Withdraw(String string){
        Balance -= Double.parseDouble(string);
    }
    //////////////////////////////// Setters methods.
    public void setBalance(double b){
        Balance = b;
    }
    public void setBalance(String string){
        Balance = Double.parseDouble(string);
    }
    //////////////////////////////// Getters method.
    public double getBalance(){
        return Balance;
    }
}
