package accounttest;

import java.util.*;
public class AccountTest {    //Student Name: Khalid Nimri
                              //Student ID: 2140145
    public static void main(String[] args) {
        System.out.println("Welcome to the bank online website!");
        Scanner input = new Scanner(System.in);         //Scanner object
        System.out.print("Please choose the number.");  //Service choice.
        Menu();                                         //Menu method to display the services.
        BankAccount Customer = new BankAccount();       //Customer object from the BankAccount class.
        int MenuChoice = input.nextInt();
        
        System.out.println("1.Sign in");              
        System.out.println("2.Sign up");
        int SigningChoice = input.nextInt();
        
        if (SigningChoice == 1){
     
         switch (MenuChoice){
             
             case 1: System.out.print("Please enter the wanted value to be Deposited: ");
                    double Num1 = input.nextDouble();
                     Customer.Deposit(Num1);
                     break;
             case 2:System.out.print("Please enter the wanted value to Withdraw: ");
                    Double Num2 = input.nextDouble();
                    Customer.Withdraw(Num2);
                    break;
             case 3:System.out.print("Please enter the new balance: ");
                    Double Num3 = input.nextDouble();
                    Customer.setBalance(Num3);
                    break;
             case 4:
                 double Bal= Customer.getBalance();
                 System.out.println("Your Balance is: " + Bal);
                 break;
                 
             default: System.out.println("Wrong! Try again.");    //sentinel value case.
         }
         Invoice(Customer.getBalance());                //To print to final invoice.
        }
        else {
            System.out.print("Please enter you balance: ");    //Asking for the balance to make it the default account balance.
            double newBal = input.nextDouble();
            BankAccount Customer1 = new BankAccount(newBal);   //New object because the customer wants to sign up.
            switch (MenuChoice){
             
             case 1: System.out.print("Please enter the wanted value to be Deposited: ");
                    double Num1 = input.nextDouble();
                     Customer1.Deposit(Num1);
                     break;
             case 2:System.out.print("Please enter the wanted value to Withdraw: ");
                    Double Num2 = input.nextDouble();
                    Customer1.Withdraw(Num2);
                    break;
             case 3:System.out.print("Please enter the new balance: ");
                    Double Num3 = input.nextDouble();
                    Customer1.setBalance(Num3);
                    break;
             case 4:
                 double Bal= Customer1.getBalance();
                 System.out.println("Your Balance is: " + Bal);
                 break;
                 
             default: Menu();
         }
            Invoice(Customer1.getBalance());            //To print to final invoice.
        }
    }       
    public static void Menu(){                          //Menu Method.
        System.out.println("\n1.Deposit.");
        System.out.println("2.Withdraw.");
        System.out.println("3.Change the balance.");
        System.out.println("4.Get the balance.");
    }
    public static void Invoice(double x){               //Invoice Method
       
        System.out.println("\n\t\tINVOICE\n");
        System.out.println("Your Balance is: " + x);
        Date d = new Date(2022,4,2);                    //New object from the Data class
        System.out.println("on: " + d );
        System.out.println("Thank you For using the bank! ");
        System.out.println("Have a nice day\n");  
    }
}
