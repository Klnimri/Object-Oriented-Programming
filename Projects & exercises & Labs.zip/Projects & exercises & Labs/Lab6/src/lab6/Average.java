/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab6;

import java.util.*;

public class Average {
   
    int Data[];
    double mean;
    
    public Average(){
        Scanner input = new Scanner(System.in);
        
        for (int i =0; i<=5; i++){
            System.out.print("\nPlease enter the number: ");
            Data[i] = input.nextInt();
        }
            SelectionSort();
            CalculateMean();
        
    }
    public void CalculateMean(){
        for (int y = 0; y <= Data.length ; y++){
            int Total;
            Total =+ y;
            int Mean;
            Mean = Total / Data.length;
            System.out.println("The mean of the numbers you have just entered is: "+Mean);
        }
    }
    public String toString(){
        return...
    }
    public void SelectionSort(){
         int max;
        for (int c = 0 ; c <= Data.length ; c++){
           
            if (Data[0]>Data[1] || Data[0]>Data[2] || Data[0] > Data[3] || Data[0]>Data[4] || Data[0]>Data[5]){
                max = Data[0];
             
            }
            else if (Data[1]>Data[0] || Data[1]>Data[2] || Data[1] > Data[3] || Data[1]>Data[4] || Data[1]>Data[5]){
                max = Data[1];
            }
            else if (Data[2]>Data[1] || Data[2]>Data[0] || Data[2] > Data[3] || Data[2]>Data[4] || Data[2]>Data[5]) {
                max =Data[2];
            }
            else if (Data[3]>Data[1] || Data[3]>Data[2] || Data[3] > Data[0] || Data[3]>Data[4] || Data[3]>Data[5]){
                max = Data[3];
            }
            if (Data[4]>Data[1] || Data[4]>Data[2] || Data[4] > Data[3] || Data[4]>Data[0] || Data[4]>Data[5]){
                max = Data[4];
            }
            else if (Data[5]>Data[1] || Data[5]>Data[2] || Data[5] > Data[3] || Data[5]>Data[4] || Data[5]>Data[0]){
                max = Data[5];
                
            }
            
        }
    }
}
