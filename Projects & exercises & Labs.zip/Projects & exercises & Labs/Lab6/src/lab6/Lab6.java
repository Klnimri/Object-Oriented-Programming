/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab6;



public class Lab6 {

    
    public static void main(String[] args) {

        Average num = new Average();
        num.CalculateMean();
    
    }
    
}
