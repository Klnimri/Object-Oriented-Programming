
package order;


import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class Order extends JFrame {

    private JButton btnMeat;
    private JButton btnFish;
    private JButton btnChicken;
    private JButton btnSoup;
    private JButton btnCombo;
    private JButton btnTotal;
    private JButton btnClear;
    private JTextArea billArea;

    DecimalFormat df = new DecimalFormat("#.##");
    private double total = 0;

    public Order() {
        Container cp = getContentPane();
        cp.setLayout(new FlowLayout());

        btnMeat = new JButton("Meat");
        btnFish = new JButton("Fish");
        btnChicken = new JButton("Chicken");
        btnSoup = new JButton("Soup");
        btnCombo = new JButton("combo drink and fries");
        btnTotal = new JButton("Checkout");
        btnClear = new JButton("Clear");
        billArea = new JTextArea(20, 30);
        billArea.setEditable(false);
        Font font = new Font("Monospaced", Font.BOLD, 12);
        billArea.setFont(font);

        cp.add(btnMeat);
        cp.add(btnFish);
        cp.add(btnChicken);
        cp.add(btnSoup);
        cp.add(btnCombo);
        cp.add(btnTotal);
        cp.add(btnClear);
        cp.add(billArea);

        btnMeat.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                billArea.append("Meat\t\t$\t 5.99\n");
                total += 5.99;

            }
        });

        btnFish.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                billArea.append("Fish\t\t$\t 6.99\n");
                total += 6.99;

            }
        });

        btnChicken.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                billArea.append("Chicken\t\t$\t 4.99\n");
                total += 4.99;

            }
        });

        btnSoup.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                billArea.append("Soup\t\t$\t 2.99\n");
                total += 2.99;
            }
        });

        btnCombo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                billArea.append("combo\t\t$\t 1.99\n");
                total += 1.99;
            }
        });

        btnTotal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    billArea.append("--------------------------------------\n");
                    billArea.append("Total\t\t\t$\t" + df.format(total) + "\n");

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter correct value.", "Error", JOptionPane.OK_OPTION);
                }
                total = 0;
            }
        });

        btnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                billArea.setText("");
                total = 0;
            }
        });
    }

    public static void main(String ar[]) {
        Order rb = new Order();
        rb.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        rb.setTitle("Restaurant UJ");
        rb.setSize(410, 410);
        rb.setVisible(true);
    }
}