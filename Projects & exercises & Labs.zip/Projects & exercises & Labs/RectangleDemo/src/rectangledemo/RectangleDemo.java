
package rectangledemo;


public class RectangleDemo {

    
    
    public static void main(String[] args) {

        int x = 5;
        Rectangle r1 = new Rectangle();              // Making an object from the Rectabgle class and using the default constructor.
       // System.out.println(r1.getLength());               // Printing the direct value of the length >> Wrong!
        //System.out.println(r1.getWidth());                // Printing the direct value of the wifth  >> Wrong!
        
        Rectangle r2 = new Rectangle();           // Making an object from the Rectangle class 
                                                     // and using the second constructor with the parameters.
        System.out.println(r1.equals(r2));
        //r2.setLength(7);                             // Setter are used to change the variables' values.
        //r2.setWidth(3);                              // Setter are used to change the variables' values.
        //System.out.println(r2.getLength());               //>>>>> System.out.println(r2.getLength()); >> This is better
        //System.out.println(r2.getWidth());    
        System.out.println(r1.getLength());//>>>>> System.out.println(r2.getWidth());  >> This is better
        r1.pp();


    }
    
}
