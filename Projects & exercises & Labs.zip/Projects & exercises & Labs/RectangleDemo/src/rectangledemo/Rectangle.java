
package rectangledemo;


public class Rectangle {
    
    private static double length=1;                                    // Declaring the variables of the class + Private to change using methods only.
    private double width;                                       // Declaring the variables of the class + Private to change using methods only.
    
    public Rectangle(){                                         // default constructor 
       length = 1;                                        // Intiallizing the variables
       width = 1;                                               // Intiallizing the variables
    }
    public Rectangle(double l , double w){                      // The second constructor 
       length = l;                                              // Intiallizing the variables to the givin parameters
       width = w;                                               // Intiallizing the variables to the givin parameters
    }
    public void setLength(double l){                            // The setter (Method) "TO CHANGE TO VALUE OF THE VARIABLE."
        length = l;                                             // Initiallizing the variable to the parameter.
    }    
    public void setWidth(double w){                             // The setter (Method) "TO CHANGE TO VALUE OF THE VARIABLE."
        width = w;                                              // Initiallizing the variable to the parameter.
    } 
    public double getLength(){                                  // The getter (Method) "TO GET THE VALUE OF THE VARIABLE AND (PRINT IT)"
        return length;                                          // Returning the variable's value.
    }
    public double getWidth(){                                   // The getter (Method) "TO GET THE VALUE OF THE VARIABLE AND (PRINT IT)"
        return width;                                           // Returning the variable's value.
    }
    public boolean equals(Rectangle a){
        if(this.length == a.length && this.width == a.width){
            return true;
        }
        else return false;
        
    }
    
    public static void pp(){
    System.out.println("helloooooooooo");
}
}

