
package urmealgui;


public
        class UrMealGUI {

    
    public static
            void main(String[] args) {
                menu a = new menu();
                
    }
    
}
