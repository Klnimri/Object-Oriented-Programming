



import java.util.*;
import javax.swing.*;

public class Television {
   private String MANUFACTURER;
   private  int SCREEN_SIZE;
   private boolean powerOn;
   private int channel;
   private int volume;
   
   public Television(String brand, int size){
       MANUFACTURER=brand;
       SCREEN_SIZE=size;
       
   }
   public void setChannel(int station){
       channel=station;
   }
   public void power(){
       powerOn=true;
       
   }
   public void increaseVolume(){
       volume=+10;
   }
   public void decreaseVolume(){
       volume=-10;
   }
   public int getChannel(){
       return channel;
   }
    public int getVolume(){
       return volume;
   }
     public String getManufacturer(){
       return MANUFACTURER;
   }
     public int getScreenSize(){
       return SCREEN_SIZE;
   }
    
}
