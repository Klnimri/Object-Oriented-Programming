/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package newclass102;

import java.util.Scanner;


public class NewClass102 {


    public static void main(String[] args) {
        
        String Name;
        int Hours;
        double PayRate;
        double GrossPay;
        
        Scanner input = new Scanner(System.in);
        
        System.out.print("Please enter you name: ");
        Name = input.nextLine();
        
        System.out.print("Please enter how many hours do you work daily: ");
        Hours= input.nextInt();
        
        System.out.print("Please enter your hourly par rate:");
        PayRate = input.nextDouble();
        
        GrossPay = Hours * PayRate;
        
        System.out.print("Hello "+ Name + ' ');
        System.out.println("Your Gross pay is $" + GrossPay);
        System.exit(0);
        
    }
    
}
