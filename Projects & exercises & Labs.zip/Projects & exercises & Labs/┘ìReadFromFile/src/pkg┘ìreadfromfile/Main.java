
package pkgٍreadfromfile;

import java.io.*;
import java.util.Scanner;

public class Main {

    
    public static void main(String[] args) throws FileNotFoundException {
       /* PrintWriter pr= new PrintWriter("Names_Employees.txt");
        pr.println("Ahmed");
        pr.println("Khalid");
        pr.println("Sami");
        pr.close();
        */
    
       String s;
       
       File f= new File("Names_Employees.txt");
       Scanner input=new Scanner(f);
       
      while (input.hasNext()){
       s = input.nextLine();
       System.out.println(s);
      }
    }
    
}
