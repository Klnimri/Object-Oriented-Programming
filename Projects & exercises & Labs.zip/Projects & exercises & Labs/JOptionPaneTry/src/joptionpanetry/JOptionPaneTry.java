/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package joptionpanetry;

import javax.swing.JOptionPane;

public class JOptionPaneTry {

    public static void main(String[] args) {

        String Name = JOptionPane.showInputDialog("Please enter your age");
        
        int Age = Integer.parseInt(Name);
        
        Age+= 20; 
        JOptionPane.showMessageDialog(null , "Your age + 20 is: "+ Age);
        System.exit(0);


    }
    
}
