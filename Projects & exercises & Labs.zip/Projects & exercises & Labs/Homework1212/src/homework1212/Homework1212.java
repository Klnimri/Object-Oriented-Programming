package homework1212;

import javax.swing.*;
public class Homework1212 { //Student name: Khalid Nimri
                            //Student ID: 2140145
    
    public static void main(String[] args) {

        String GradeStr = JOptionPane.showInputDialog("Please enter your grade");
        int GradeInt = Integer.parseInt(GradeStr);
        
        JOptionPane.showMessageDialog(null, "Your grade is " + GetGrade(GradeInt)
                + " Which mean you " + PassStatus(GradeInt));
        System.exit(0);
    }

    public static String GetGrade(int Grade) {

        String GradeLetter;
        if (Grade <= 100 && Grade >= 95) {
            GradeLetter = "A+";
        } else if (Grade >= 90 && Grade < 95) {
            GradeLetter = "A";
        } else if (Grade >= 85 && Grade < 90) {
            GradeLetter = "B+";
        } else if (Grade >= 80 && Grade < 85) {
            GradeLetter = "B";
        } else if (Grade >= 75 && Grade < 80) {
            GradeLetter = "C+";
        } else if (Grade >= 70 && Grade < 75) {
            GradeLetter = "C";
        } else if (Grade >= 65 && Grade < 70) {
            GradeLetter = "D+";
        } else if (Grade >= 60 && Grade < 65) {
            GradeLetter = "D";
        } else {
            GradeLetter = "F";
        }
        return GradeLetter;
    }
    public static String PassStatus(int GradeStatus) {
        String Status;

        if (GradeStatus >= 60) {
            Status = "Pass";
        } else {
            Status = "Failed";
        }
        return Status;
    }
}
