
package task3;              //Student Name: Khalid nimri
                            //Student ID: 2140145

import java.awt.event.*;
import javax.swing.*;

public class Task3 extends JFrame {

    private JComboBox comboBox = new JComboBox();
    private JButton addButton = new JButton("Add Item");
    private JButton removeButton = new JButton("Remove an Item");
    private JButton removeAllButtons = new JButton("Remove All Items");
    private JLabel label = new JLabel("Total Item = 0");
    private JTextField textField = new JTextField(10);
    ////////////////////////
    JPanel panel = new JPanel();
    
    public Task3() {

        setTitle("");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setSize(500,300);
        
        
        textField.setBounds(40, 40, 110, 30);
        addButton.setBounds(170, 40, 120, 30);
        removeButton.setBounds(40, 80, 250, 30);
        removeAllButtons.setBounds(40, 120, 250, 30);
        comboBox.setBounds(310, 40, 140, 30);
        label.setBounds(310, 80, 140, 30);
        ////////////////////////
        panel.add(textField);
        panel.add(addButton);
        panel.add(removeButton);
        panel.add(removeAllButtons);
        panel.add(comboBox);
        panel.add(label);
        ////////////////////////
        panel.setLayout(null);
        ////////////////////////
        add(panel);
        setVisible(true);
        ////////////////////////
        addButton.addActionListener(new AddListener());
        removeButton.addActionListener(new AddListener());
        removeAllButtons.addActionListener(new AddListener());
    }
        ////////////////////////
    private class AddListener implements ActionListener {
        
        @Override
        public void actionPerformed(ActionEvent e) {
         ////////////////////////
            if (e.getSource() == addButton) 
            {
                if (!textField.getText().equals("")) 
                {
          ////////////////////////
                    comboBox.addItem(textField.getText());
          ////////////////////////
                    label.setText("Total Item = " + comboBox.getItemCount());
                }
            } 
           ////////////////////////
            if (e.getSource() == removeButton) 
            {
           ////////////////////////
                comboBox.removeItemAt(comboBox.getSelectedIndex());
           ////////////////////////
                label.setText("Total Item = " + comboBox.getItemCount());
            } 
            ////////////////////////
            if (e.getSource() ==removeAllButtons ) 
            {
            ////////////////////////
                comboBox.removeAllItems();
            ////////////////////////
                label.setText("Total Item = " + comboBox.getItemCount());
            }
        }
    }

    public static void main(String[] args) {
        
        Task3 t = new Task3();   
    }
}
