package applicationdisplay;         //Student name: Khalid Nimri
                                    //Student ID: 2140145
import java.awt.*;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.AbstractListModel;
import javax.swing.event.*;

public class ApplicationDisplay extends JFrame {

private JPanel contentPane;
private JTextField txt;
private JLabel lblNewLabel;
private JLabel lblYouSelected;
private JList list;
    public static void main(String[] args) 
    {
    EventQueue.invokeLater(new Runnable() 
    {
	public void run() 
        {
	try {
		ApplicationDisplay frame = new ApplicationDisplay();
                frame.setVisible(true);
		
            } 
                catch (Exception e) 
                {
                    e.printStackTrace();
		}
	}
});
}

	public ApplicationDisplay() {
                JFrame k = new JFrame();
		k.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		k.setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		
		contentPane.setLayout(new FlowLayout(FlowLayout.CENTER,15,10));
		
		lblNewLabel = new JLabel("please select your favourite season:");
		lblNewLabel.setBounds(31, 27, 240, 23);
		contentPane.add(lblNewLabel);
                
		list = new JList();
                list.addListSelectionListener(new ListListener());
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"Winter", "Summer", "Spring"};
			public int getSize() 
                        {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		
		contentPane.add(list);
                
		lblYouSelected = new JLabel("You Selected:\n");
		lblYouSelected.setBounds(31, 155, 240, 23);
		contentPane.add(lblYouSelected);
		
		txt = new JTextField(10);
                txt.setEditable(false);
		contentPane.add(txt);
		
		k.add(contentPane);
                k.setVisible(true);
        }
        public class ListListener implements ListSelectionListener{
    

	 public void valueChanged(ListSelectionEvent e)
	    {
	        
		 txt.setText(String.valueOf(list.getSelectedValue()));
	         
	    }
        }
}
