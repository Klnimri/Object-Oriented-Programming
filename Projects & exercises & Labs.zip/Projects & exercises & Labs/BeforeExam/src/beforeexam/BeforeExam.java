
package beforeexam;
import java.util.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import java.awt.*;

public
        class BeforeExam {

   
    
    
    public static
            void main(String[] args) {
                KiloConv K = new KiloConv();
            
            }
    
    public class KiloConv extends JFrame{
    private JPanel panel;
    private JLabel label;
    private JTextField TxtFld;
    private JButton button;
    private final int WINDOW_WIDTH= 310;
    private final int WINDOW_HEIGHT = 210;
    
    public KiloConv(){
        setTitle("Welcome to KiloConvApp");
        setSize(WINDOW_WIDTH,WINDOW_HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        BuildPanel();
        add(panel);
        setVisible(true);
        
    }
        public void BuildPanel(){
            panel = new JPanel();
            label = new JLabel("Please enter the distance in kilos:");
            TxtFld = new JTextField(10);
            button = new JButton("Calculate");
            button.addActionListener(new CalcButtonListener());
            panel.add(label);
            panel.add(TxtFld);
            panel.add(button);
            
        }
        
  
    public class CalcButtonListener implements ActionListener{
        public void actionPerformed(ActionEvent e){
            final double CONVERSION = 0.6214;
            String TxtInput = TxtFld.getText();
            double Miles = Double.parseDouble(TxtInput) * CONVERSION;
            JOptionPane.showMessageDialog(null, TxtInput + " in kilos is :" + Miles + " in Miles.");
        }
    }
}
}