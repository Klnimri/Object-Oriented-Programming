package printer;            //Student name: Khalid Nimri
                            //Student ID: 2140145
import javax.swing.*;
import java.awt.*;


class Printer extends JFrame
{
    JLabel lab1,lab2;
    JCheckBox cb1,cb2,cb3,cb4;
    JRadioButton r1,r2,r3;
    JButton b1,b2,b3,b4;
    JComboBox combo;
    

    Printer()
    {
       String ar[] = {"High","Low","Middle"};
       Container c = getContentPane();
        c.setLayout(null);

        lab1 = new JLabel("Printer: MyPrinter");
        lab1.setBounds(50,50,300,30);
        
        cb1 = new JCheckBox("Image");
        cb1.setBounds(150,100,100,30);
        
        cb2 = new JCheckBox("Text");
        cb2.setBounds(150,130,100,30);
        
        cb3 = new JCheckBox("Code");
        cb3.setBounds(150,160,100,30);

        r1 = new JRadioButton("Selection");
        r1.setBounds(250,100,100,30);
        
        r2 = new JRadioButton("All",true);
        r2.setBounds(250,130,100,30);
        
        r3 = new JRadioButton("Applet");
        r3.setBounds(250,160,100,30);

        b1 = new JButton("Ok");
        b1.setBounds(380,100,100,30);

        
        b2 = new JButton("Cancel");
        b2.setBounds(380,140,100,30);

        
        b3 = new JButton("Setup...");
        b3.setBounds(380,180,100,30);

        
        b4 = new JButton("Help");
        b4.setBounds(380,220,100,30);

        lab2 = new JLabel("Print Quality:");
        lab2.setBounds(110,220,100,30);

        combo = new JComboBox(ar);
        combo.setBounds(190,220,60,30);

        cb4 = new JCheckBox("Print to File");
        cb4.setBounds(270,220,100,30);

        c.add(lab1);c.add(lab2);
        c.add(cb1);c.add(cb2);c.add(cb3);c.add(cb4);
        c.add(r1);c.add(r2);c.add(r3);
        c.add(b1);c.add(b2);c.add(b3);c.add(b4);
        c.add(combo);
    }

    public static void main(String args[])
    {
        Printer p = new Printer();
        p.setTitle("Printer");
        p.setSize(700,500);
        p.setVisible(true);
    }
}