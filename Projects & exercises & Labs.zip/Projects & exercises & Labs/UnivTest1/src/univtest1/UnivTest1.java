package univtest1;


public class UnivTest1 {

    
    public static void main(String[] args) {
        Student s1 = new Student("Ahmed", "Khalid", "123", "Jeddah","0540031222",4.5);
        //System.out.println(s1);
        Student i1 = new Student("Dr.Ibrahim","Mohammed","37162", "Mecca", "05400381821", 8);
        //System.out.println(i1);
        //Person k = new Student();
        System.out.println(s1.greater(i1));


    }
    
}
