package univtest1;


public class Instructor extends Person {
    
 
   private double salary;
   
   public Instructor(){
       
   }
   
   public Instructor(String f, String l, String id, String Address, 
                    String mobileNumber, double s){
       super(f,l,id,Address,mobileNumber);
       salary=s;
       
   }
   
   public String toString(){
       return super.toString()+"Salary " + salary + '\n';
   }
}
