/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package univtest1;


public class Person {
    
   private String fName;
   private String lName;
   private String ID;
   private String address;
   private String MobileNumber;
   
   public Person(){
       
   }
   public Person(String f, String l, String id, String Address, 
                    String mobileNumber){
       this.fName=f;
       this.lName=l;
       this.ID=id;
       this.address=Address;
       this.MobileNumber=mobileNumber;
       
   }
    public String toString(){
       return "\nName: "+fName + ' '+ lName + '\n'+ "ID: "+ ID + '\n'+
               "address: " + address + '\n'+ "MobileNumber: " + MobileNumber + '\n';
            
   }
}
