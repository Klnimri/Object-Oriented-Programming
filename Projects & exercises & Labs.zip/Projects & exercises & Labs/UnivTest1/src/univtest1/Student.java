package univtest1;
 

public class Student extends Person implements Relatable{
    
  
   private double gpa;
   
   public Student(){

}
   public Student(String f, String l, String id, String Address, 
                    String mobileNumber, double g){
      
       super(f, l ,id, Address,mobileNumber); 
       gpa = g;
       
}
   @Override
   public String toString(){
       return super.toString() + "Gpa: " + gpa;
   }
    public boolean greater(Student s){
       if (gpa>s.gpa){
           return true;
       }
       else {
           return false;
       }
   }
}

